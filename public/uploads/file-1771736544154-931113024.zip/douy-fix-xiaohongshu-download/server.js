const express = require('express');
const axios = require('axios');
const cheerio = require('cheerio');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

// 设置静态文件目录
app.use(express.static('public'));

// 解析JSON请求体
app.use(express.json());

// 提取URL的函数
function extractUrl(text) {
  // 首先去除前后空格
  text = text.trim();
  
  // 直接返回完整URL（如果输入是完整URL）
  try {
    new URL(text);
    return text;
  } catch (e) {
    // 不是完整URL，尝试提取
  }
  
  // 定义各种平台的链接正则表达式
  const platformPatterns = [
    // 抖音链接
    {
      name: 'douyin',
      patterns: [
        /https?:\/\/v\.douyin\.com\/[a-zA-Z0-9_]+\/?/g,
        /https?:\/\/(?:www\.)?(?:douyin\.com|iesdouyin\.com|aweme\.snssdk\.com|api\.amemv\.com|api-hl\.amemv\.com|v16-web\.douyinvod\.com)\S+?\/?(?=\s|$)/g
      ]
    },
    // 小红书链接
    {
      name: 'xiaohongshu',
      patterns: [
        // 桌面版探索页链接
        /https?:\/\/(?:www\.)?xiaohongshu\.com\/explore\/[\w\-]+/g,
        // 桌面版发现页链接
        /https?:\/\/(?:www\.)?xiaohongshu\.com\/discovery\/item\/[\w\-]+/g,
        // 桌面版直接item链接
        /https?:\/\/(?:www\.)?xiaohongshu\.com\/item\/[\w\-]+/g,
        // 移动版链接
        /https?:\/\/m\.xiaohongshu\.com\/[\w\-\/]+/g,
        // 短链接（包含/o/路径）
        /https?:\/\/xhslink\.com\/(?:o\/)?[a-zA-Z0-9_]+\/?/g,
        // 无www前缀的链接
        /https?:\/\/xiaohongshu\.com\/[\w\-\/]+/g,
        // CDN视频链接
        /https?:\/\/(?:sns-video-qc|sns-video-va)\.xhscdn\.com\/[\w\-\/\.]+\.(mp4|mov|webm)/g,
        // CDN图片链接（可能包含视频相关信息）
        /https?:\/\/(?:sns-img)\.xhscdn\.com\/[\w\-\/\.]+/g
      ]
    },
    // 快手链接
    {
      name: 'kuaishou',
      patterns: [
        /https?:\/\/(?:www\.)?kuaishou\.com\/[\w\-\/]+/g,
        /https?:\/\/v\.kuaishou\.com\/[a-zA-Z0-9_]+\/?/g
      ]
    },
    // 微博链接
    {
      name: 'weibo',
      patterns: [
        /https?:\/\/(?:www\.)?weibo\.com\/[\w\-\/]+/g,
        /https?:\/\/m\.weibo\.cn\/[\w\-\/]+/g,
        /https?:\/\/weibo\.cn\/[\w\-\/]+/g
      ]
    }
  ];
  
  // 遍历所有平台的链接模式
  for (const platform of platformPatterns) {
    for (const pattern of platform.patterns) {
      const matches = text.match(pattern);
      if (matches && matches[0]) {
        let url = matches[0];
        // 只清理URL末尾的特殊字符，保留URL结构
        url = url.replace(/[\s"\'<>,.;:!@#$%^&*()_+\-=\[\]{}|\\~`]$/g, '');
        return url;
      }
    }
  }
  
  // 尝试匹配通用URL，确保只匹配到URL结束
  const generalUrlRegex = /https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b[-a-zA-Z0-9()@:%_\+.~#?&//=]*?\/?(?=\s|$)/g;
  let matches = text.match(generalUrlRegex);
  
  if (matches && matches[0]) {
    let url = matches[0];
    // 只清理URL末尾的特殊字符，保留URL结构
    url = url.replace(/[\s"\'<>,.;:!@#$%^&*()_+\-=\[\]{}|\\~`]$/g, '');
    return url;
  }
  
  // 最后的兜底方案：匹配任何以http开头的字符串，直到空格或结束
  const lastResortRegex = /https?:\/\/\S+?\/?(?=\s|$)/g;
  matches = text.match(lastResortRegex);
  
  if (matches && matches[0]) {
    let url = matches[0];
    // 只清理URL末尾的特殊字符，保留URL结构
    url = url.replace(/[\s"\'<>,.;:!@#$%^&*()_+\-=\[\]{}|\\~`]$/g, '');
    return url;
  }
  
  return null;
}

// 验证URL有效性的函数
function isValidUrl(url) {
  try {
    new URL(url);
    return true;
  } catch (error) {
    return false;
  }
}

// 处理媒体下载请求
app.post('/api/download', async (req, res) => {
  try {
    let { url } = req.body;
    if (!url) {
      return res.status(400).json({ error: '请提供媒体URL' });
    }

    // 提取纯URL（处理用户可能粘贴的包含其他文本的链接）
    const extractedUrl = extractUrl(url);
    if (!extractedUrl) {
      return res.status(400).json({ error: '未找到有效的URL，请检查输入' });
    }

    // 验证URL格式
    if (!isValidUrl(extractedUrl)) {
      return res.status(400).json({ error: 'URL格式无效，请检查输入' });
    }

    url = extractedUrl;

    // 检测媒体平台
    let platform = '';
    if (url.includes('douyin.com') || url.includes('tiktok.com')) {
      platform = 'douyin';
    } else if (url.includes('kuaishou.com')) {
      platform = 'kuaishou';
    } else if (url.includes('xiaohongshu.com') || url.includes('xhslink.com')) {
      platform = 'xiaohongshu';
    } else if (url.includes('weibo.com')) {
      platform = 'weibo';
    } else {
      return res.status(400).json({ error: '不支持的媒体平台' });
    }

    // 根据平台处理下载
    let downloadUrl = '';
    switch (platform) {
      case 'douyin':
        downloadUrl = await handleDouyin(url);
        break;
      case 'kuaishou':
        downloadUrl = await handleKuaishou(url);
        break;
      case 'xiaohongshu':
        downloadUrl = await handleXiaohongshu(url);
        break;
      case 'weibo':
        downloadUrl = await handleWeibo(url);
        break;
      default:
        return res.status(400).json({ error: '不支持的媒体平台' });
    }

    // 返回下载链接
    res.json({ success: true, downloadUrl: downloadUrl, platform: platform });
  } catch (error) {
    console.error('下载失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// 代理下载接口，解决跨域下载问题
app.get('/api/proxy-download', async (req, res) => {
  try {
    const { url, preview } = req.query;
    if (!url) {
      return res.status(400).json({ error: '请提供下载URL' });
    }

    console.log('代理请求:', { url, preview: !!preview });

    // 解码URL，防止编码问题
    const decodedUrl = decodeURIComponent(url);
    console.log('解码后的URL:', decodedUrl);

    // 验证URL格式
    try {
      new URL(decodedUrl);
    } catch (e) {
      console.error('无效的URL格式:', decodedUrl);
      return res.status(400).json({ error: '无效的URL格式' });
    }

    // 获取文件流，增加重试机制
    let response;
    let retryCount = 3;
    let success = false;
    
    // 重试机制
    while (retryCount > 0 && !success) {
      try {
        console.log(`尝试获取文件流，重试次数: ${3 - retryCount + 1}`);
        response = await axios.get(decodedUrl, {
          responseType: 'stream',
          headers: {
            // 使用更可靠的移动端User-Agent
            'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
            'Accept': preview ? 'video/mp4,video/*;q=0.9,*/*;q=0.8' : 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            // 根据视频源动态设置Referer和Origin
            'Referer': decodedUrl.includes('xiaohongshu') || decodedUrl.includes('xhs') || decodedUrl.includes('xhscdn') ? 'https://www.xiaohongshu.com/' : 'https://www.douyin.com/',
            'Origin': decodedUrl.includes('xiaohongshu') || decodedUrl.includes('xhs') || decodedUrl.includes('xhscdn') ? 'https://www.xiaohongshu.com/' : 'https://www.douyin.com/',
            'Sec-Fetch-Dest': preview ? 'video' : 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'cross-site',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Cache-Control': 'no-cache',
            'X-Requested-With': 'XMLHttpRequest',
            'TE': 'trailers'
          },
          timeout: 30000, // 增加超时时间
          maxRedirects: 10, // 增加重定向次数
          validateStatus: function (status) {
            return status >= 200 && status < 500; // 接受更多状态码
          },
          // 配置TLS选项，解决TLS握手问题
          httpsAgent: new (require('https').Agent)({
            rejectUnauthorized: false, // 忽略证书错误
            keepAlive: true,
            timeout: 30000,
            secureProtocol: 'TLSv1_2_method' // 明确指定TLS版本
          })
        });
        success = true;
        break;
      } catch (error) {
        retryCount--;
        console.log(`获取文件流失败，剩余重试次数: ${retryCount}，错误: ${error.message}`);
        console.error('重试错误详情:', error);
        if (retryCount === 0) {
          throw error;
        }
        // 等待一段时间后重试
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }

    console.log('代理响应状态:', response.status);
    console.log('代理响应头:', response.headers);
    console.log('代理响应数据类型:', typeof response.data);

    // 检查响应是否为空
    if (!response.data) {
      console.error('代理失败: 响应数据为空');
      return res.status(500).json({ error: '代理失败: 视频源返回空数据' });
    }

    // 获取文件大小和类型
    const contentLength = parseInt(response.headers['content-length'] || '0');
    const contentType = response.headers['content-type'] || 'video/mp4';
    
    console.log(`最终文件信息: 大小=${contentLength} 字节, 类型=${contentType}`);
    
    // 检查文件大小是否为0
    if (contentLength === 0) {
      console.error('代理失败: 视频文件大小为0');
      return res.status(500).json({ error: '代理失败: 视频源返回空文件' });
    }

    // 设置响应头
    res.setHeader('Content-Type', contentType);
    
    // 如果是预览请求，不设置attachment，允许浏览器直接播放
    if (req.query.preview) {
      res.setHeader('Content-Disposition', `inline; filename="video_preview.mp4"`);
    } else {
      res.setHeader('Content-Disposition', `attachment; filename="video_${Date.now()}.mp4"`);
    }
    
    // 只有当contentLength大于0时才设置Content-Length
    if (contentLength > 0) {
      res.setHeader('Content-Length', contentLength);
    }
    
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Accept-Ranges', 'bytes'); // 支持范围请求，便于视频播放
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate'); // 禁用缓存
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    
    // 设置成功状态码
    res.writeHead(200);

    // 直接将响应流管道到客户端，简化逻辑
    response.data.pipe(res);
    
    // 监听结束事件
    response.data.on('end', () => {
      console.log('代理传输完成');
      if (!res.writableEnded) {
        res.end();
      }
    });

    // 监听错误事件
    response.data.on('error', (err) => {
      console.error('代理流错误:', err);
      if (!res.writableEnded && !res.headersSent) {
        res.status(500).json({ error: '代理失败: 视频流传输错误' });
      } else if (!res.writableEnded) {
        // 如果响应头已经发送，但连接还没有结束，直接结束响应
        res.end();
      }
    });

    // 监听连接关闭事件
    res.on('close', () => {
      console.log('客户端关闭连接');
      // 销毁请求流，释放资源
      if (response.data) {
        response.data.destroy();
      }
    });

  } catch (error) {
    console.error('代理请求失败:', error);
    console.error('错误详情:', error.response ? JSON.stringify(error.response.data) : error.message);
    console.error('错误堆栈:', error.stack);
    
    // 确保响应未发送
    if (!res.headersSent) {
      // 如果是预览请求，返回JSON错误信息
      if (req.query.preview) {
        res.status(500).json({ 
          error: `代理请求失败: ${error.message}`,
          tip: '抖音服务器可能有访问限制，建议尝试以下方法：1. 稍后重试 2. 使用手机APP分享的链接 3. 检查网络连接' 
        });
      } else {
        // 如果是下载请求，返回HTML页面，避免浏览器下载JSON文件
        res.setHeader('Content-Type', 'text/html; charset=utf-8');
        res.status(500).send(`
          <!DOCTYPE html>
          <html lang="zh-CN">
          <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>下载失败</title>
            <style>
              body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; text-align: center; }
              h1 { color: #e74c3c; }
              .error-message { color: #333; margin: 20px 0; }
              .tip { background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0; text-align: left; }
              .tip h3 { margin-top: 0; color: #666; }
              .tip ul { margin: 10px 0; padding-left: 20px; }
              .back-btn { display: inline-block; padding: 10px 20px; background: #3498db; color: white; text-decoration: none; border-radius: 5px; margin-top: 20px; }
              .back-btn:hover { background: #2980b9; }
            </style>
          </head>
          <body>
            <h1>下载失败</h1>
            <div class="error-message">
              <p>很抱歉，视频下载失败了。</p>
              <p>错误信息：${error.message}</p>
            </div>
            <div class="tip">
              <h3>解决建议：</h3>
              <ul>
                <li>检查网络连接是否正常</li>
                <li>可能是服务器暂时不可用，请稍后重试</li>
                <li>确保使用的是有效的视频分享链接</li>
                <li>可以尝试复制提取到的视频链接到浏览器直接下载</li>
              </ul>
            </div>
            <a href="/" class="back-btn">返回首页</a>
          </body>
          </html>
        `);
      }
    }
  }
});

// 处理抖音下载
async function handleDouyin(url) {
  try {
    // 1. 处理短链接
    if (url.includes('v.douyin.com')) {
      console.log('处理抖音短链接...');
      const shortResponse = await axios.get(url, {
        maxRedirects: 10,
        headers: {
          'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1'
        },
        timeout: 15000
      });
      url = shortResponse.request.res.responseUrl || url;
      console.log('短链接解析后的URL:', url);
    }

    // 2. 获取页面内容
    const response = await axios.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1'
      },
      timeout: 15000
    });
    const html = response.data;

    // 3. 解析页面获取视频信息
    const $ = cheerio.load(html);
    let videoUrl = '';

    // 尝试从script标签获取数据
    $('script').each((index, element) => {
      const scriptContent = $(element).html() || '';
      if (scriptContent.includes('__PLAYBACK_API_HYDRATION__')) {
        try {
          const dataMatch = scriptContent.match(/__PLAYBACK_API_HYDRATION__\s*=\s*({[\s\S]+?});/);
          if (dataMatch && dataMatch[1]) {
            const videoData = JSON.parse(dataMatch[1]);
            console.log('视频数据结构:', Object.keys(videoData));
            
            // 获取视频URL
            const videoObj = videoData.data?.itemList?.[0]?.video;
            if (videoObj) {
              // 选择最高清晰度的视频
              const bitrates = videoObj.bitRateList || [];
              if (bitrates.length > 0) {
                // 按码率排序，选择最高码率
                bitrates.sort((a, b) => b.bitRate - a.bitRate);
                videoUrl = bitrates[0].playAddr;
              } else if (videoObj.playAddr) {
                videoUrl = videoObj.playAddr;
              } else if (videoObj.coverUrlList?.[0]) {
                // 兜底使用封面图
                videoUrl = videoObj.coverUrlList[0];
              }
            }
          }
        } catch (error) {
          console.error('解析抖音视频数据失败:', error);
        }
        return false; // 跳出循环
      }
    });

    // 如果没有找到视频URL，尝试其他方法
    if (!videoUrl) {
      // 查找包含视频URL的meta标签
      const videoMeta = $('meta[property="og:video"]').attr('content');
      if (videoMeta) {
        videoUrl = videoMeta;
        console.log('从meta标签获取视频URL:', videoUrl);
      } else {
        // 查找包含视频的iframe
        const videoIframe = $('iframe[src*="aweme"]').attr('src');
        if (videoIframe) {
          // 从iframe的src中获取视频信息
          console.log('找到视频iframe:', videoIframe);
          // 这里可以进一步解析iframe内容获取视频URL
          // 作为兜底，返回iframe的src
          videoUrl = videoIframe;
        } else {
          // 尝试从script标签中直接提取视频URL
          const videoRegex = /https?:\/\/[\w\-\.]+\/[\w\-\/\.]+\.(mp4|mov|webm)/g;
          const matches = html.match(videoRegex);
          if (matches && matches.length > 0) {
            videoUrl = matches[0];
            console.log('从HTML直接提取视频URL:', videoUrl);
          }
        }
      }
    }

    if (!videoUrl) {
      throw new Error('未找到视频链接，请检查抖音链接是否正确\n\n提示：\n1. 确保是抖音视频链接\n2. 使用手机APP分享的完整链接\n3. 稍后重试（抖音有访问限制）');
    }

    // 去除水印
    if (videoUrl.includes('watermark=1')) {
      videoUrl = videoUrl.replace('watermark=1', 'watermark=0');
      console.log('去除水印后的视频链接:', videoUrl);
    }

    // 补全协议（如果需要）
    if (!videoUrl.startsWith('http')) {
      videoUrl = 'https:' + videoUrl;
      console.log('补全协议后的视频链接:', videoUrl);
    }

    return videoUrl;
  } catch (error) {
    console.error('抖音处理失败:', error);
    throw new Error('抖音视频处理失败：' + error.message + '\n\n提示：\n1. 检查链接是否正确\n2. 使用手机APP分享的完整链接\n3. 稍后重试（抖音有访问限制）');
  }
}

// 处理快手下载
async function handleKuaishou(url) {
  // 快手下载逻辑（需要根据快手最新接口调整）
  throw new Error('快手功能开发中');
}

// 处理小红书下载
async function handleXiaohongshu(url) {
  try {
    console.log('处理小红书链接:', url);
    
    // 确保URL以http或https开头
    if (!url.startsWith('http')) {
      url = 'https://' + url;
      console.log('补全协议后的URL:', url);
    }
    
    // ==== 1. 处理短链接，获取真实URL ====  
    if (url.includes('xhslink.com')) {
      console.log('处理小红书短链接...');
      
      // 先检查是否是不完整的短链接
      if (url.includes('xhslink.com/o/') && (url.endsWith('xhslink.com/o/') || url.endsWith('o/'))) {
        throw new Error('无效的小红书链接，请提供完整的分享链接\n\n提示：\n1. 链接格式不完整\n2. 请确保从手机APP复制完整的分享链接\n3. 完整链接示例：https://xhslink.com/abc123 或 https://xhslink.com/o/abc123');
      }
      
      // 验证短链接格式，支持两种格式：xhslink.com/abc123 和 xhslink.com/o/abc123
      const shortIdMatch = url.match(/xhslink\.com\/(?:o\/)?([a-zA-Z0-9_]+)/);
      if (!shortIdMatch || !shortIdMatch[1]) {
        throw new Error('无效的小红书短链接\n\n提示：\n1. 短链接格式示例：https://xhslink.com/abc123 或 https://xhslink.com/o/abc123\n2. 确保链接包含完整的短链接ID\n3. 从手机APP复制完整链接');
      }
      
      try {
        // 尝试使用HEAD请求获取重定向URL，避免下载完整页面
        const shortResponse = await axios.head(url, { 
          maxRedirects: 10, // 增加重定向次数
          headers: {
            'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
            'Referer': 'https://www.xiaohongshu.com/',
            'Cookie': 'xhsTrackerId=xxx; abRequestId=xxx' // 增加空Cookie头
          },
          timeout: 15000 // 增加超时时间
        });
        
        // 获取重定向后的最终URL
        url = shortResponse.request.res.responseUrl || url;
        console.log('短链接解析后的URL:', url);
      } catch (e) {
        console.log('短链接解析失败，尝试使用GET请求...');
        try {
          // 如果HEAD请求失败，尝试使用GET请求，但只获取头信息
          const getResponse = await axios.get(url, { 
            maxRedirects: 10, // 增加重定向次数
            headers: {
              'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
              'Referer': 'https://www.xiaohongshu.com/',
              'Cookie': 'xhsTrackerId=xxx; abRequestId=xxx' // 增加空Cookie头
            },
            timeout: 15000, // 增加超时时间
            responseType: 'stream' // 不下载完整内容
          });
          
          // 获取重定向后的最终URL
          url = getResponse.request.res.responseUrl || url;
          console.log('短链接GET解析后的URL:', url);
          
          // 关闭流
          getResponse.data.destroy();
        } catch (getErr) {
          console.log('短链接GET解析也失败，使用原始URL:', getErr.message);
          // 从短链接提取ID
          const shortId = shortIdMatch[1];
          console.log('从短链接提取到ID:', shortId);
          
          // 尝试解码
          try {
            const decodedId = decodeURIComponent(shortId);
            console.log('解码后的短链接ID:', decodedId);
            
            // 构建完整URL
            url = `https://www.xiaohongshu.com/explore/${decodedId}`;
            console.log('构建的完整URL:', url);
            
          } catch (decodeErr) {
            console.log('ID解码失败，使用原始ID:', shortId);
            // 使用原始ID构建URL
            url = `https://www.xiaohongshu.com/explore/${shortId}`;
            console.log('构建的完整URL:', url);
          }
        }
      }
    }
    
    // ==== 2. 提取笔记ID ====  
    console.log('提取笔记ID...');
    let noteId = '';
    
    // 处理可能以/结尾的URL
    if (url.endsWith('/')) {
      url = url.slice(0, -1);
      console.log('去除末尾斜杠后的URL:', url);
    }
    
    // 2. 尝试多种方式提取笔记ID，增加成功率
    const regexPatterns = [
      // 标准格式：https://www.xiaohongshu.com/explore/64d7e3c90000000027030593
      /explore\/(\w{24})/i,
      // 发现页格式：https://www.xiaohongshu.com/discovery/item/64d7e3c90000000027030593
      /discovery\/item\/(\w{24})/i,
      // 直接item格式：https://www.xiaohongshu.com/item/64d7e3c90000000027030593
      /item\/(\w{24})/i,
      // 短链接可能包含的格式：https://xhslink.com/64d7e3c90000000027030593
      /xhslink\.com\/([a-zA-Z0-9_]{6,})/i,
      // 任何位置的24位十六进制ID
      /\b([0-9a-f]{24})\b/i
    ];
    
    let foundId = false;
    for (const pattern of regexPatterns) {
      const match = url.match(pattern);
      if (match && match[1]) {
        noteId = match[1];
        console.log('从正则匹配提取到笔记ID:', noteId);
        foundId = true;
        break;
      }
    }
    
    // 3. 如果正则匹配失败，尝试从URL路径提取
    if (!foundId) {
      const urlParts = url.split('?')[0].replace(/\/$/, '').split('/');
      noteId = urlParts[urlParts.length - 1];
      console.log('从URL路径提取到笔记ID:', noteId);
    }
    
    // 4. 验证笔记ID格式，小红书笔记ID通常是24位十六进制数
    // 但放宽验证，允许各种格式的ID都尝试获取
    let isStandardId = /^[0-9a-f]+$/i.test(noteId) && noteId.length >= 16;
    
    if (!isStandardId) {
      console.log('非标准格式的笔记ID:', noteId);
      
      // 尝试从URL参数中提取标准ID
      try {
        const params = new URL(url).searchParams;
        const noteIdParam = params.get('note_id') || params.get('id') || params.get('noteId');
        if (noteIdParam && /^[0-9a-f]+$/i.test(noteIdParam)) {
          noteId = noteIdParam;
          console.log('从URL参数提取到标准笔记ID:', noteId);
          isStandardId = true;
        } else {
          // 最后尝试解码URL，看是否包含ID
          const decodedUrl = decodeURIComponent(url);
          for (const pattern of regexPatterns) {
            const match = decodedUrl.match(pattern);
            if (match && match[1] && /^[0-9a-f]+$/i.test(match[1])) {
              noteId = match[1];
              console.log('从解码URL提取到标准笔记ID:', noteId);
              foundId = true;
              isStandardId = true;
              break;
            }
          }
          
          // 即使不是标准ID，也继续尝试获取视频
          console.log('继续使用非标准ID尝试获取视频');
        }
      } catch (decodeErr) {
        console.log('URL参数处理失败:', decodeErr.message);
        // 即使处理失败，也继续尝试获取视频
        console.log('继续使用当前ID尝试获取视频');
      }
    }
    
    console.log('最终提取到的笔记ID:', noteId);
    
    // ==== 3. 获取页面HTML内容 ====  
    console.log('获取小红书页面内容...');
    
    // 使用更真实的浏览器请求头，提高成功率
    // 模拟真实浏览器环境，包括更多关键头信息
    const headers = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Referer': 'https://www.xiaohongshu.com/',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
      'Accept-Encoding': 'gzip, deflate, br',
      'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-US;q=0.7',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Pragma': 'no-cache',
      'Sec-Ch-Ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
      'Sec-Ch-Ua-Mobile': '?0',
      'Sec-Ch-Ua-Platform': '"Windows"',
      'Sec-Fetch-Dest': 'document',
      'Sec-Fetch-Mode': 'navigate',
      'Sec-Fetch-Site': 'none',
      'Sec-Fetch-User': '?1',
      'Upgrade-Insecure-Requests': '1',
      'X-Requested-With': 'XMLHttpRequest',
      'Cookie': 'xhsTrackerId=xxx; abRequestId=xxx; webId=xxx; Hm_lvt_32440c204b368c6a054794718207c90c=123456789; Hm_lpvt_32440c204b368c6a054794718207c90c=123456789; xhs_spider=xxx; xhs_seg=xxx; xhsTracker=xxx',
      'Host': 'www.xiaohongshu.com'
    };
    
    const htmlResponse = await axios.get(url, {
      headers: headers,
      timeout: 15000,
      // 启用gzip压缩，提高请求速度
      decompress: true
    });
    
    const html = htmlResponse.data;
    console.log('HTML获取成功，长度:', html.length);
    
    // ==== 4. 解析HTML，提取视频链接 ====  
    console.log('解析HTML，提取视频链接...');
    
    let videoUrl = '';
    
    // 1. 增强的CDN视频URL提取，支持更多格式和域名
    console.log('尝试直接从HTML提取CDN视频URL...');
    const cdnVideoRegex = /(https?:\/\/(?:sns-video|sns-video-qc|sns-video-va|sns-xvpp|any-video|video|video-hw|video-1)\.(?:xhscdn|xiaohongshu)\.com\/[\w\-\/\.\?=&%_@+]+\.(mp4|mov|webm|flv))/g;
    const cdnMatches = html.match(cdnVideoRegex);
    if (cdnMatches && cdnMatches.length > 0) {
      // 去重并选择最长的URL（通常是高清版本）
      const uniqueUrls = [...new Set(cdnMatches)];
      videoUrl = uniqueUrls.sort((a, b) => b.length - a.length)[0];
      console.log('直接找到CDN视频URL:', videoUrl);
    } 
    
    // 2. 尝试提取更多格式的视频链接
    if (!videoUrl) {
      console.log('尝试提取更多格式的视频链接...');
      
      // 增强的视频提取正则表达式列表
      const videoRegexPatterns = [
        /videoUrl\s*:\s*["']([^"']+[\.](?:mp4|mov|webm))["']/g,
        /"(https?:\/\/[^"']+\.(mp4|mov|webm|flv))"/g,
        /'(https?:\/\/[^"']+\.(mp4|mov|webm|flv))'/g,
        /url\s*:\s*["']([^"']+\.(mp4|mov|webm|flv))["']/g,
        /playAddr\s*:\s*["']([^"']+\.(mp4|mov|webm|flv))["']/g,
        /src\s*=\s*["']([^"']+\.(mp4|mov|webm|flv))["']/g,
        /data-src\s*=\s*["']([^"']+\.(mp4|mov|webm|flv))["']/g,
        /poster\s*=\s*["']([^"']+\.(mp4|mov|webm|flv))["']/g,
        /"(\/\/[^"]+\.(mp4|mov|webm|flv))"/g
      ];
      
      // 尝试所有正则表达式
      for (const pattern of videoRegexPatterns) {
        const matches = html.match(pattern);
        if (matches && matches.length > 0) {
          // 筛选有效的URL
          const validUrls = matches.filter(match => 
            /(mp4|mov|webm|flv)$/.test(match) && 
            (match.includes('http') || match.includes('//'))
          ).map(match => {
            // 清理URL，去除引号和其他无关字符
            let cleaned = match.replace(/^["']|["]+$/, '')
                               .replace(/^videoUrl\s*:\s*["']|playAddr\s*:\s*["']|src\s*=\s*["']|data-src\s*=\s*["']|poster\s*=\s*["']|url\s*:\s*["']/i, '')
                               .replace(/["']$/, '');
            
            // 补全协议
            if (cleaned.startsWith('//')) {
              cleaned = 'https:' + cleaned;
            }
            
            return cleaned;
          });
          
          if (validUrls.length > 0) {
            // 选择最长的URL（通常是最高质量）
            videoUrl = validUrls.sort((a, b) => b.length - a.length)[0];
            console.log(`使用正则${pattern.source.substring(0, 30)}...提取到视频URL:`, videoUrl);
            break;
          }
        }
      }
    }
    
    // 3. 尝试提取页面状态数据
    if (!videoUrl) {
      console.log('尝试提取页面状态数据...');
      
      // 尝试提取各种状态数据
      const statePatterns = [
        /window\.__INITIAL_STATE__\s*=\s*({[\s\S]+?})(?:;|\s*<\/script>)/i,
        /window\.__data__\s*=\s*({[\s\S]+?})(?:;|\s*<\/script>)/i,
        /window\.__APP_INIT_DATA__\s*=\s*({[\s\S]+?})(?:;|\s*<\/script>)/i,
        /window\.pageData\s*=\s*({[\s\S]+?})(?:;|\s*<\/script>)/i,
        /window\.initialState\s*=\s*({[\s\S]+?})(?:;|\s*<\/script>)/i,
        /window\.state\s*=\s*({[\s\S]+?})(?:;|\s*<\/script>)/i
      ];
      
      let stateData = null;
      for (const pattern of statePatterns) {
        const match = html.match(pattern);
        if (match && match[1]) {
          try {
            // 替换JSON字符串中的undefined为null，避免解析失败
            const sanitizedJson = match[1].replace(/undefined/g, 'null');
            stateData = JSON.parse(sanitizedJson);
            console.log('找到状态数据:', pattern.source.substring(0, 20) + '...');
            break;
          } catch (e) {
            console.log('解析状态数据失败:', e.message);
          }
        }
      }
      
      // 如果找到状态数据，尝试提取视频URL
      if (stateData) {
        console.log('尝试从状态数据中提取视频URL...');
        
        // 添加调试信息，查看状态数据的基本结构
        console.log('状态数据类型:', typeof stateData);
        console.log('状态数据是否包含noteDetailMap:', 'noteDetailMap' in stateData);
        console.log('状态数据是否包含global:', 'global' in stateData);
        console.log('状态数据是否包含note:', 'note' in stateData);
        
        // 检查noteDetailMap
        if (stateData.noteDetailMap) {
          console.log('noteDetailMap包含的键:', Object.keys(stateData.noteDetailMap));
          const firstNoteKey = Object.keys(stateData.noteDetailMap)[0];
          if (firstNoteKey) {
            const firstNote = stateData.noteDetailMap[firstNoteKey];
            console.log('第一个笔记是否包含video:', 'video' in firstNote);
            if (firstNote.video) {
              console.log('视频对象结构:', JSON.stringify(firstNote.video, null, 2).substring(0, 1000) + '...');
            }
          }
        }
        
        // 定义一个递归搜索视频URL的函数 - 增强版
        const searchVideoUrl = (obj) => {
          if (typeof obj !== 'object' || obj === null) return null;
          
          // 定义视频相关字段
          const videoFields = ['url', 'urls', 'playAddr', 'videoUrl', 'src', 'dataSrc', 'originalUrl', 'cdnUrl', 'downloadUrl', 'streamUrl', 'masterUrl', 'backupUrls'];
          
          // 检查是否是视频对象
          if (obj.type === 'video' || obj.video) {
            const videoObj = obj.video || obj;
            
            // 尝试所有视频字段
            for (const field of videoFields) {
              if (videoObj[field]) {
                if (Array.isArray(videoObj[field]) && videoObj[field].length > 0) {
                  return videoObj[field][0];
                } else if (typeof videoObj[field] === 'string') {
                  return videoObj[field];
                }
              }
            }
            
            // 处理复杂的视频媒体结构（如状态数据中的格式）
            if (videoObj.media && videoObj.media.stream) {
              const stream = videoObj.media.stream;
              
              // 处理h264、h265、h266、av1等不同编码格式
              const codecs = ['h264', 'h265', 'h266', 'av1'];
              for (const codec of codecs) {
                if (stream[codec] && Array.isArray(stream[codec]) && stream[codec].length > 0) {
                  // 获取第一个流
                  const firstStream = stream[codec][0];
                  
                  // 优先使用masterUrl
                  if (firstStream.masterUrl) {
                    return firstStream.masterUrl;
                  }
                  
                  // 其次使用backupUrls
                  if (firstStream.backupUrls && firstStream.backupUrls.length > 0) {
                    return firstStream.backupUrls[0];
                  }
                }
              }
            }
          }
          
          // 检查是否是资源对象
          if (obj.resource && obj.resource.video) {
            const videoObj = obj.resource.video;
            
            // 尝试所有视频字段
            for (const field of videoFields) {
              if (videoObj[field]) {
                if (Array.isArray(videoObj[field]) && videoObj[field].length > 0) {
                  return videoObj[field][0];
                } else if (typeof videoObj[field] === 'string') {
                  return videoObj[field];
                }
              }
            }
          }
          
          // 检查常见的数据结构
          const commonStructures = ['content', 'note', 'data', 'item', 'items', 'list', 'detail', 'info', 'result', 'payload', 'response', 'noteDetailMap'];
          
          for (const structure of commonStructures) {
            if (obj[structure]) {
              const result = searchVideoUrl(obj[structure]);
              if (result) return result;
            }
          }
          
          // 检查列表结构
          if (Array.isArray(obj)) {
            for (const item of obj) {
              const result = searchVideoUrl(item);
              if (result) return result;
            }
          }
          
          // 递归搜索所有属性
          for (const key in obj) {
            try {
              const result = searchVideoUrl(obj[key]);
              if (result) return result;
            } catch (e) {
              // 跳过无法访问的属性
              continue;
            }
          }
          
          return null;
        };
        
        const foundUrl = searchVideoUrl(stateData);
        if (foundUrl) {
          videoUrl = foundUrl;
          console.log('从状态数据中提取到视频URL:', videoUrl);
        } else {
          // 尝试直接访问已知的小红书视频URL路径
          console.log('尝试直接访问已知的小红书视频URL路径...');
          // 检查stateData.note.noteDetailMap（正确路径）
          if (stateData.note && stateData.note.noteDetailMap) {
            const noteKeys = Object.keys(stateData.note.noteDetailMap);
            for (const noteKey of noteKeys) {
              const noteDetail = stateData.note.noteDetailMap[noteKey];
              if (noteDetail.note && noteDetail.note.video && noteDetail.note.video.media && noteDetail.note.video.media.stream) {
                const stream = noteDetail.note.video.media.stream;
                // 检查h264编码
                if (stream.h264 && Array.isArray(stream.h264) && stream.h264.length > 0) {
                  const h264Stream = stream.h264[0];
                  if (h264Stream.masterUrl) {
                    videoUrl = h264Stream.masterUrl;
                    console.log('从h264.masterUrl提取到视频URL:', videoUrl);
                    break;
                  } else if (h264Stream.backupUrls && Array.isArray(h264Stream.backupUrls) && h264Stream.backupUrls.length > 0) {
                    videoUrl = h264Stream.backupUrls[0];
                    console.log('从h264.backupUrls提取到视频URL:', videoUrl);
                    break;
                  }
                }
                // 检查其他编码格式
                const otherCodecs = ['h265', 'h266', 'av1'];
                for (const codec of otherCodecs) {
                  if (stream[codec] && Array.isArray(stream[codec]) && stream[codec].length > 0) {
                    const codecStream = stream[codec][0];
                    if (codecStream.masterUrl) {
                      videoUrl = codecStream.masterUrl;
                      console.log(`从${codec}.masterUrl提取到视频URL:`, videoUrl);
                      break;
                    } else if (codecStream.backupUrls && Array.isArray(codecStream.backupUrls) && codecStream.backupUrls.length > 0) {
                      videoUrl = codecStream.backupUrls[0];
                      console.log(`从${codec}.backupUrls提取到视频URL:`, videoUrl);
                      break;
                    }
                  }
                }
                if (videoUrl) break;
              }
            }
          }
        }
      }
    }
    
    // 4. 如果没有找到，使用Cheerio解析HTML
    if (!videoUrl) {
      console.log('使用Cheerio解析HTML...');
      const $ = cheerio.load(html);
      
      // 查找video标签
      const videoElement = $('video').first();
      if (videoElement.length > 0) {
        // 查找video的source标签
        const sourceElement = videoElement.find('source').first();
        if (sourceElement.length > 0) {
          videoUrl = sourceElement.attr('src');
          console.log('从video标签提取到视频链接:', videoUrl);
        } else {
          // 尝试获取video的data-src属性
          const dataSrc = videoElement.attr('data-src');
          if (dataSrc) {
            videoUrl = dataSrc;
            console.log('从video标签提取到data-src:', videoUrl);
          }
          // 尝试获取video的poster属性
          const poster = videoElement.attr('poster');
          if (poster) {
            console.log('从video标签提取到poster:', poster);
          }
        }
      }
      
      // 5. 查找所有script标签，提取更多可能的视频链接
      if (!videoUrl) {
        console.log('尝试从所有script标签提取视频信息...');
        
        let foundVideo = false;
        $('script').each((index, element) => {
          const scriptContent = $(element).html() || '';
          
          // 尝试直接提取CDN视频URL
          const directVideoMatch = scriptContent.match(/(https?:\/\/(?:sns-video|sns-video-qc|sns-video-va|sns-xvpp|any-video|video)\.(?:xhscdn|xiaohongshu)\.com\/[\w\-\/\.\?=&%_@]+\.(mp4|mov|webm|flv))/g);
          if (directVideoMatch && directVideoMatch.length > 0) {
            videoUrl = directVideoMatch[0];
            console.log('从script标签直接找到视频URL:', videoUrl);
            foundVideo = true;
            return false; // 跳出循环
          }
          
          // 尝试提取JSON数据中的视频链接
          try {
            // 查找包含video的JSON对象
            if (scriptContent.includes('video') && (scriptContent.includes('url') || scriptContent.includes('urls'))) {
              // 尝试提取更完整的JSON结构
              const jsonMatch = scriptContent.match(/(\{[\s\S]*?\})/);
              if (jsonMatch) {
                try {
                  const jsonData = JSON.parse(jsonMatch[0]);
                  // 使用递归函数搜索视频链接
                  const findVideoInJson = (obj) => {
                    if (typeof obj !== 'object' || obj === null) return null;
                    if (obj.url && typeof obj.url === 'string' && (obj.url.endsWith('.mp4') || obj.url.endsWith('.mov') || obj.url.endsWith('.webm'))) {
                      return obj.url;
                    }
                    if (obj.urls && Array.isArray(obj.urls) && obj.urls.length > 0) {
                      return obj.urls[0];
                    }
                    if (obj.video && typeof obj.video === 'object') {
                      const videoResult = findVideoInJson(obj.video);
                      if (videoResult) return videoResult;
                    }
                    for (const key in obj) {
                      const result = findVideoInJson(obj[key]);
                      if (result) return result;
                    }
                    return null;
                  };
                  
                  const foundInJson = findVideoInJson(jsonData);
                  if (foundInJson) {
                    videoUrl = foundInJson;
                    console.log('从script JSON中找到视频URL:', videoUrl);
                    foundVideo = true;
                    return false; // 跳出循环
                  }
                } catch (jsonErr) {
                  // 解析失败，继续尝试
                }
              }
            }
          } catch (e) {
            console.log('从script提取视频信息失败:', e.message);
          }
        });
      }
    }
    
    // 保存调试信息
    if (!videoUrl) {
      console.log('未找到视频链接，保存调试信息...');
      fs.writeFileSync('xiaohongshu_debug.html', html.substring(0, 30000) + '...');
      console.log('调试HTML已保存到 xiaohongshu_debug.html');
    }
    
    // 如果仍然没有找到视频链接，尝试API请求获取
    if (!videoUrl) {
      console.log('尝试通过API请求获取视频链接...');
      
      // 增强的API端点列表
      const apiEndpoints = [
        `https://www.xiaohongshu.com/api/sns/web/v1/note/info?note_id=${noteId}`,
        `https://www.xiaohongshu.com/api/sns/web/v1/feed?source_note_id=${noteId}`,
        `https://www.xiaohongshu.com/api/sns/web/v1/note/view?note_id=${noteId}`,
        `https://www.xiaohongshu.com/api/sns/web/v1/note/detail?note_id=${noteId}`,
        `https://www.xiaohongshu.com/api/sns/web/v1/comment/list?note_id=${noteId}&page=1&page_size=1`
      ];
      
      // 统一的API请求配置
      const apiConfig = {
        timeout: 20000,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Referer': url,
          'Accept': 'application/json, text/plain, */*',
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
          'Cookie': 'xhsTrackerId=xxx; abRequestId=xxx; webId=xxx; Hm_lvt_32440c204b368c6a054794718207c90c=123456789; Hm_lpvt_32440c204b368c6a054794718207c90c=123456789; xhs_spider=xxx; xhs_seg=xxx; xhsTracker=xxx',
          'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-US;q=0.7',
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache',
          'Sec-Ch-Ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
          'Sec-Ch-Ua-Mobile': '?0',
          'Sec-Ch-Ua-Platform': '"Windows"',
          'Sec-Fetch-Dest': 'empty',
          'Sec-Fetch-Mode': 'cors',
          'Sec-Fetch-Site': 'same-origin'
        }
      };
      
      for (const apiUrl of apiEndpoints) {
        try {
          const apiResponse = await axios.get(apiUrl, apiConfig);
          
          console.log(`API请求(${apiUrl})成功，状态码:`, apiResponse.status);
          
          // 解析API响应获取视频链接 - 使用增强版搜索函数
          const findVideoUrl = (obj) => {
            if (typeof obj !== 'object' || obj === null) return null;
            
            // 定义视频相关字段
            const videoFields = ['url', 'urls', 'playAddr', 'videoUrl', 'src', 'dataSrc', 'originalUrl', 'cdnUrl', 'downloadUrl', 'streamUrl', 'uri', 'masterUrl', 'backupUrls'];
            
            // 检查常见的视频字段
            if (obj.video) {
              const videoObj = obj.video;
              for (const field of videoFields) {
                if (videoObj[field]) {
                  if (Array.isArray(videoObj[field]) && videoObj[field].length > 0) {
                    return videoObj[field][0];
                  } else if (typeof videoObj[field] === 'string') {
                    return videoObj[field];
                  }
                }
              }
              
              // 处理复杂的视频媒体结构（如状态数据中的格式）
              if (videoObj.media && videoObj.media.stream) {
                const stream = videoObj.media.stream;
                
                // 处理h264、h265、h266、av1等不同编码格式
                const codecs = ['h264', 'h265', 'h266', 'av1'];
                for (const codec of codecs) {
                  if (stream[codec] && Array.isArray(stream[codec]) && stream[codec].length > 0) {
                    // 获取第一个流
                    const firstStream = stream[codec][0];
                    
                    // 优先使用masterUrl
                    if (firstStream.masterUrl) {
                      return firstStream.masterUrl;
                    }
                    
                    // 其次使用backupUrls
                    if (firstStream.backupUrls && firstStream.backupUrls.length > 0) {
                      return firstStream.backupUrls[0];
                    }
                  }
                }
              }
            }
            
            // 检查资源字段
            if (obj.resource && obj.resource.video) {
              const videoObj = obj.resource.video;
              for (const field of videoFields) {
                if (videoObj[field]) {
                  if (Array.isArray(videoObj[field]) && videoObj[field].length > 0) {
                    return videoObj[field][0];
                  } else if (typeof videoObj[field] === 'string') {
                    return videoObj[field];
                  }
                }
              }
            }
            
            // 检查播放信息字段
            if (obj.play_info) {
              if (obj.play_info.url) {
                return obj.play_info.url;
              } else if (obj.play_info.video && obj.play_info.video.url) {
                return obj.play_info.video.url;
              }
            }
            
            // 检查其他常见的数据结构
            const commonStructures = ['content', 'note', 'data', 'item', 'items', 'list', 'detail', 'info', 'result', 'payload', 'response', 'media', 'resource'];
            
            for (const structure of commonStructures) {
              if (obj[structure]) {
                const result = findVideoUrl(obj[structure]);
                if (result) return result;
              }
            }
            
            // 检查列表结构
            if (Array.isArray(obj)) {
              for (const item of obj) {
                const result = findVideoUrl(item);
                if (result) return result;
              }
            }
            
            // 递归搜索所有属性
            for (const key in obj) {
              try {
                const result = findVideoUrl(obj[key]);
                if (result) return result;
              } catch (e) {
                // 跳过无法访问的属性
                continue;
              }
            }
            
            return null;
          };
          
          const apiData = apiResponse.data;
          const apiVideoUrl = findVideoUrl(apiData);
          if (apiVideoUrl) {
            videoUrl = apiVideoUrl;
            console.log('从API获取到视频链接:', videoUrl);
            break;
          }
          
        } catch (error) {
          console.log(`API请求(${apiUrl})失败:`, error.message);
          // 继续尝试下一个API
        }
      }
    }
    
    // 如果所有API都失败，尝试构造直接的视频URL
    if (!videoUrl) {
      console.log('尝试构造直接的视频URL...');
      
      // 增强的CDN视频URL构造模式
      const cdnPatterns = [
        `https://sns-video-qc.xhscdn.com/${noteId}.mp4`,
        `https://sns-video-va.xhscdn.com/${noteId}.mp4`,
        `https://sns-video-qc.xhscdn.com/${noteId.substring(0, 8)}/${noteId}.mp4`,
        `https://sns-video-va.xhscdn.com/${noteId.substring(0, 8)}/${noteId}.mp4`,
        `https://sns-video-qc.xhscdn.com/${noteId.substring(0, 12)}/${noteId}.mp4`,
        `https://sns-video-va.xhscdn.com/${noteId.substring(0, 12)}/${noteId}.mp4`,
        `https://sns-video-qc.xhscdn.com/video/${noteId}.mp4`,
        `https://sns-video-va.xhscdn.com/video/${noteId}.mp4`
      ];
      
      // 尝试验证CDN URL是否存在
      for (const cdnUrl of cdnPatterns) {
        try {
          // 随机延迟，避免请求过于频繁
          await new Promise(resolve => setTimeout(resolve, Math.random() * 1000));
          
          const headResponse = await axios.head(cdnUrl, {
            headers: {
              'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
              'Referer': 'https://www.xiaohongshu.com/',
              'Accept': 'video/mp4,video/webm,video/ogg,application/x-mpegURL,application/vnd.apple.mpegURL,video/*;q=0.9,application/*;q=0.8,*/*;q=0.7',
              'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-US;q=0.7',
              'Origin': 'https://www.xiaohongshu.com',
              'Cookie': 'xhsTrackerId=xxx; abRequestId=xxx; webId=xxx;'
            },
            timeout: 10000,
            maxRedirects: 5
          });
          
          if (headResponse.status >= 200 && headResponse.status < 300) {
            videoUrl = cdnUrl;
            console.log('验证CDN视频URL成功:', videoUrl);
            break;
          }
        } catch (error) {
          // CDN URL不存在或请求失败，继续尝试下一个
          console.log(`CDN URL(${cdnUrl})验证失败:`, error.message);
        }
      }
    }
    
    // 最后的兜底方案：使用更可靠的API
    if (!videoUrl) {
      console.log('尝试最终兜底方案...');
      try {
        // 尝试使用移动版API
        const mobileApiUrl = `https://www.xiaohongshu.com/api/sns/v1/note/${noteId}/single_feed?note_id=${noteId}`;
        const mobileResponse = await axios.get(mobileApiUrl, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
            'Referer': `https://m.xiaohongshu.com/note/${noteId}`,
            'Accept': 'application/json, text/plain, */*'
          },
          timeout: 15000
        });
        
        console.log(`移动版API请求成功，状态码:`, mobileResponse.status);
        
        // 解析移动版API响应
        const mobileVideoUrl = findVideoUrl(mobileResponse.data);
        if (mobileVideoUrl) {
          videoUrl = mobileVideoUrl;
          console.log('从移动版API获取到视频链接:', videoUrl);
        } else {
          throw new Error('未从移动版API找到视频链接');
        }
      } catch (error) {
        console.log('最终兜底方案失败:', error.message);
        throw new Error('无法获取视频链接，请检查链接是否正确或稍后重试\n\n提示：\n1. 链接可能已过期\n2. 小红书可能有访问限制\n3. 请使用手机APP分享的完整链接\n4. 稍后重试');
      }
    }
    
    // 确保URL完整
    if (!videoUrl.startsWith('http')) {
      videoUrl = 'https:' + videoUrl;
      console.log('补全协议后的视频链接:', videoUrl);
    }
    
    // 处理可能的水印
    if (videoUrl.includes('watermark=1')) {
      videoUrl = videoUrl.replace('watermark=1', 'watermark=0');
      console.log('去除水印后的视频链接:', videoUrl);
    } else if (videoUrl.includes('wm=1')) {
      videoUrl = videoUrl.replace('wm=1', 'wm=0');
      console.log('去除水印后的视频链接:', videoUrl);
    }
    
    return videoUrl;
    
  } catch (error) {
    console.error('小红书处理失败:', error);
    throw new Error('小红书视频处理失败：' + error.message + '\n\n提示：\n1. 检查链接是否正确\n2. 使用手机APP分享的完整链接\n3. 稍后重试（小红书有访问限制）');
  }
}

// 处理微博下载
async function handleWeibo(url) {
  // 微博下载逻辑（需要根据微博最新接口调整）
  throw new Error('微博功能开发中');
}

// 启动服务器
app.listen(PORT, () => {
  console.log(`服务器运行在 http://localhost:${PORT}`);
});
