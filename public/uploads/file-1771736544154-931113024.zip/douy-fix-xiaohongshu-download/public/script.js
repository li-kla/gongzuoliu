document.addEventListener('DOMContentLoaded', () => {
    const mediaUrlInput = document.getElementById('mediaUrl');
    const downloadBtn = document.getElementById('downloadBtn');
    const statusDiv = document.getElementById('status');
    const resultDiv = document.getElementById('result');

    downloadBtn.addEventListener('click', async () => {
        const url = mediaUrlInput.value.trim();
        if (!url) {
            showStatus('请输入媒体链接', 'error');
            return;
        }

        showStatus('正在处理，请稍候...', 'loading');
        resultDiv.innerHTML = '';

        try {
            const response = await fetch('/api/download', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ url })
            });

            const data = await response.json();

            if (data.success) {
                showStatus('处理完成，点击链接下载', 'success');
                showResult(data.downloadUrl);
            } else {
                showStatus(data.error || '下载失败', 'error');
            }
        } catch (error) {
            console.error('请求失败:', error);
            showStatus('网络错误，请稍后重试', 'error');
            // 显示详细的错误信息到控制台，方便调试
            console.log('错误详情:', error);
        }
    });

    // 回车键触发下载
    mediaUrlInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            downloadBtn.click();
        }
    });

    function showStatus(message, type) {
        statusDiv.textContent = message;
        statusDiv.className = `status ${type}`;
    }

    function showResult(downloadUrl) {
        console.log('原始视频URL:', downloadUrl);
        // 使用代理下载接口，解决跨域问题
        const encodedUrl = encodeURIComponent(downloadUrl);
        const proxyUrl = `/api/proxy-download?url=${encodedUrl}`;
        
        // 生成随机的视频文件名
        const randomFilename = `video_${Date.now()}.mp4`;
        
        // 简化界面，只保留预览和下载按钮
        resultDiv.innerHTML = `
            <div class="preview-section">
                <video controls width="100%" height="auto" style="max-width: 600px; margin-bottom: 15px;">
                    <source src="${proxyUrl}&preview=1" type="video/mp4">
                    您的浏览器不支持HTML5视频预览
                </video>
            </div>
            <div class="download-options">
                <a href="${proxyUrl}" class="download-btn" download="${randomFilename}" target="_self">点击下载</a>
            </div>
            <div class="download-info">
                <small style="color: #666;">点击按钮后，浏览器会自动开始下载</small>
            </div>
        `;
    }
    
    // 直接使用a标签下载，简化下载流程
});