// 测试URL解析功能
const fs = require('fs');
const path = require('path');

// 读取server.js文件
const serverContent = fs.readFileSync(path.join(__dirname, 'server.js'), 'utf8');

// 提取extractUrl函数
const extractUrlMatch = serverContent.match(/function extractUrl\(text\)\s*{([\s\S]*?)^\s*}/m);
if (extractUrlMatch && extractUrlMatch[1]) {
  // 创建一个临时文件来测试extractUrl函数
  const testCode = `
${extractUrlMatch[0]}

// 测试用户提供的抖音链接
const testText = '3.51 复制打开抖音，看看【丁元英视角的作品】25岁人生，虽然迷茫、焦虑但并不孤单 "都说25岁... \`https://v.douyin.com/znlaKum2zJ8/\`  WMw:/ G@I.iP 05/30 。你要学会从这个链接中解析出正确的URL';

console.log('测试文本:', testText);
console.log('\n提取结果:', extractUrl(testText));
`;
  
  // 写入测试文件
  fs.writeFileSync(path.join(__dirname, 'test-extract-url.js'), testCode, 'utf8');
  
  console.log('测试脚本已创建，运行测试...');
  
  // 运行测试脚本
  const { exec } = require('child_process');
  exec('node test-extract-url.js', (error, stdout, stderr) => {
    if (error) {
      console.error('测试失败:', error);
      return;
    }
    if (stderr) {
      console.error('测试错误:', stderr);
      return;
    }
    console.log(stdout);
    
    // 删除临时测试文件
    fs.unlinkSync(path.join(__dirname, 'test-extract-url.js'));
  });
} else {
  console.error('未能提取extractUrl函数');
}