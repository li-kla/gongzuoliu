// 测试URL解析功能

// 直接复制extractUrl函数的完整实现
function extractUrl(text) {
  // 首先去除前后空格
  text = text.trim();
  
  // 直接返回完整URL（如果输入是完整URL）
  try {
    new URL(text);
    return text;
  } catch (e) {
    // 不是完整URL，尝试提取
  }
  
  // 增强对抖音链接的支持，特别是用户提供的格式
  // 匹配抖音短链接格式：https://v.douyin.com/xxxx/
  const douyinShortUrlRegex = /(https?:\/\/v\.douyin\.com\/[a-zA-Z0-9_]+\/?)/g;
  let matches = text.match(douyinShortUrlRegex);
  
  if (matches && matches[0]) {
    let url = matches[0];
    // 清理URL，确保格式正确
    url = url.replace(/[\s"'<>.,;:!@#$%^&*()_+\-=\[\]{}|\\/?~`]/g, '');
    return url;
  }
  
  // 匹配其他抖音链接格式
  const douyinUrlRegex = /(https?:\/\/(?:www\.)?(?:douyin\.com|iesdouyin\.com|aweme\.snssdk\.com|api\.amemv\.com|api-hl\.amemv\.com|v16-web\.douyinvod\.com)\S+?\/?(?:\s|$))/g;
  matches = text.match(douyinUrlRegex);
  
  if (matches && matches[0]) {
    let url = matches[0];
    // 清理URL中的多余字符，只保留到URL结束
    url = url.replace(/[\s"'<>.,;:!@#$%^&*()_+\-=\[\]{}|\\/?~`]/g, '');
    return url;
  }
  
  // 尝试匹配通用URL，确保只匹配到URL结束
  const generalUrlRegex = /(https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b[-a-zA-Z0-9()@:%_\+.~#?&//=]*?\/?)(?:\s|$)/g;
  matches = text.match(generalUrlRegex);
  
  if (matches && matches[0]) {
    let url = matches[0];
    // 清理URL中的多余字符
    url = url.replace(/[\s"'<>.,;:!@#$%^&*()_+\-=\[\]{}|\\/?~`]/g, '');
    return url;
  }
  
  // 最后的兜底方案：匹配任何以http开头的字符串，直到空格或结束
  const lastResortRegex = /(https?:\/\/\S+?\/?)(?:\s|$)/g;
  matches = text.match(lastResortRegex);
  
  if (matches && matches[0]) {
    let url = matches[0];
    // 清理URL中的多余字符
    url = url.replace(/[\s"'<>.,;:!@#$%^&*()_+\-=\[\]{}|\\/?~`]/g, '');
    return url;
  }
  
  return null;
}

// 测试用户提供的抖音链接
const testText = '3.51 复制打开抖音，看看【丁元英视角的作品】25岁人生，虽然迷茫、焦虑但并不孤单 "都说25岁... `https://v.douyin.com/znlaKum2zJ8/`  WMw:/ G@I.iP 05/30 。你要学会从这个链接中解析出正确的URL';

console.log('测试文本:', testText);
console.log('\n提取结果:', extractUrl(testText));

// 测试纯URL
const pureUrl = 'https://v.douyin.com/znlaKum2zJ8/';
console.log('\n纯URL测试结果:', extractUrl(pureUrl));

// 测试带额外文本的URL
const mixedUrl = '看看这个视频 https://v.douyin.com/znlaKum2zJ8/ 真不错';
console.log('\n混合URL测试结果:', extractUrl(mixedUrl));

// 测试其他格式的抖音链接
const otherFormat = 'https://www.douyin.com/video/1234567890';
console.log('\n其他格式测试结果:', extractUrl(otherFormat));