# 媒体下载器

一个支持多种主流媒体平台的视频下载工具，提供简单易用的前端界面和强大的后端解析功能。

## 功能特性

- ✨ **多平台支持**：支持抖音、快手、小红书、微博等主流媒体平台
- 📱 **短链接解析**：自动解析各种平台的短链接，提取真实视频地址
- 🎥 **视频预览**：下载前可预览视频内容
- 📥 **一键下载**：点击即可快速下载视频
- 🚀 **代理下载**：内置代理功能解决跨域下载问题
- 💻 **简单界面**：简洁直观的用户界面，操作便捷

## 支持的平台

- 抖音 (douyin.com / tiktok.com)
- 快手 (kuaishou.com)
- 小红书 (xiaohongshu.com / xhslink.com)
- 微博 (weibo.com)

## 安装步骤

1. **克隆项目**
   ```bash
   git clone https://github.com/li-kla/douy.git
   cd douy
   ```

2. **安装依赖**
   ```bash
   npm install
   ```

3. **启动服务**
   ```bash
   npm run dev
   ```

4. **访问应用**
   打开浏览器访问：`http://localhost:3000`

## 使用说明

1. **复制链接**：从支持的媒体平台复制视频分享链接
2. **粘贴链接**：将链接粘贴到输入框中
3. **点击下载**：点击"下载"按钮，系统会自动解析视频
4. **预览与下载**：解析完成后，可预览视频，点击"点击下载"按钮即可下载视频

## 项目结构

```
douy/
├── public/             # 前端静态文件
│   ├── index.html      # 主页面
│   ├── script.js       # 前端脚本
│   └── style.css       # 样式文件
├── server.js           # 后端服务器
├── package.json        # 项目配置
└── README.md           # 项目说明
```

## 技术栈

- **后端**：Node.js + Express
- **前端**：HTML5 + CSS3 + JavaScript
- **HTTP客户端**：Axios
- **开发工具**：Nodemon (热重载)

## 注意事项

1. 本工具仅供个人学习和研究使用，请遵守各平台的使用条款
2. 某些平台可能会对视频下载进行限制，导致下载失败
3. 如果遇到下载问题，可尝试刷新页面或稍后重试
4. 请确保网络连接正常，代理下载需要稳定的网络环境

## 许可证

MIT License

## 贡献

欢迎提交Issue和Pull Request来帮助改进这个项目！

## 联系方式

如有问题或建议，可通过以下方式联系：
- GitHub: [https://github.com/li-kla/douy](https://github.com/li-kla/douy)
