
function extractUrl(text) {
  // 首先去除前后空格
  text = text.trim();
  
  // 直接返回完整URL（如果输入是完整URL）
  try {
    new URL(text);
    return text;
  }

// 测试用户提供的抖音链接
const testText = '3.51 复制打开抖音，看看【丁元英视角的作品】25岁人生，虽然迷茫、焦虑但并不孤单 "都说25岁... `https://v.douyin.com/znlaKum2zJ8/`  WMw:/ G@I.iP 05/30 。你要学会从这个链接中解析出正确的URL';

console.log('测试文本:', testText);
console.log('
提取结果:', extractUrl(testText));
